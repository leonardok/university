/*
 *  class_scheduler.h
 *  schedsim_rr
 *
 *  Created by Leonardo Korndorfer on 4/22/10.
 *  Copyright 2010. All rights reserved.
 *
 */

task_t * schedule(void);
void increase_sleep_time(void);
void increase_wait_time(void);