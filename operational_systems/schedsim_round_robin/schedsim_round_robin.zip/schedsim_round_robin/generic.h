/*
 *  task.h
 *  schedsim_rr
 *
 *  Created by Leonardo Korndorfer on 4/22/10.
 *  Copyright 2010. All rights reserved.
 *
 */

#ifndef __GENERIC_HEADER__
#define __GENERIC_HEADER__

#define TRUE  1
#define FALSE 0



#endif __GENERIC_HEADER__